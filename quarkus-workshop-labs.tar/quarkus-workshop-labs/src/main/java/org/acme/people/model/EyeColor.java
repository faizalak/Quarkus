package org.acme.people.model;

public enum EyeColor {
    BLUE, GREEN, HAZEL, BROWN
}